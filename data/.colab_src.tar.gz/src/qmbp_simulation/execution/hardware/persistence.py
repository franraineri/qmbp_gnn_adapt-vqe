"""Persistence of hardware execution results.

Saves all artifacts from a hardware run into a timestamped directory
using result_io utilities and StructuredLogger for execution logs.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from qmbp_simulation.utils.helpers import json_serialize

if TYPE_CHECKING:
    from qmbp_simulation.execution.hardware.config import HardwareConfig, HardwareRunResult
    from qmbp_simulation.framework.logging import StructuredLogger


def _collect_metadata(seed: int | None = None) -> dict[str, Any]:
    """Collect run metadata with lazy import to avoid circular dependency."""
    from qmbp_simulation.framework.result_io import collect_run_metadata

    return collect_run_metadata(seed=seed)


def _write_json(data: Any, path: Path) -> None:
    """Write data to JSON with numpy/Path/datetime-safe serialization."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=json_serialize)


def _build_mitigation_snapshot(config: HardwareConfig) -> dict[str, Any]:
    """Build a scalable mitigation config snapshot from HardwareConfig.

    Auto-serializes the entire MitigationOptions dataclass plus execution
    parameters. When new techniques or parameters are added to MitigationOptions,
    they appear here automatically without editing persistence code.

    The snapshot also includes derived/computed fields useful for analysis
    (e.g. total_learning_shots, effective twirling mode).
    """
    # Base: full dataclass serialization (captures ALL current and future fields)
    mitigation_raw = asdict(config.mitigation)

    # Structured view organized by technique (for human readability)
    snapshot: dict[str, Any] = {
        # Raw dataclass dump — captures everything, even fields added later
        "_raw_mitigation_options": mitigation_raw,
        # Execution parameters
        "execution": {
            "shots_per_layout": config.shots,
            "n_layouts": config.n_layouts,
            "job_timeout_s": config.job_timeout_s,
            "optimization_level": config.optimization_level,
            "backend_name": config.backend_name,
            "mode": config.mode,
        },
        # Per-technique structured view (for easy querying)
        "techniques": {
            "dynamical_decoupling": {
                "enabled": config.mitigation.dd_enabled,
                "sequence_type": "XpXm",
                "skip_reset_qubits": True,
                "scheduling_method": "alap",
            },
            "pauli_twirling": {
                "enabled": config.mitigation.twirling_enabled,
                "enable_gates": config.mitigation.twirling_enabled,
                "enable_measure": (
                    config.mitigation.twirling_enabled and config.mitigation.trex_enabled
                ),
                "num_randomizations": (
                    config.mitigation.num_randomizations
                    if config.mitigation.zne_amplifier == "pea"
                    else None
                ),
                "shots_per_randomization": (
                    config.mitigation.shots_per_randomization
                    if config.mitigation.zne_amplifier == "pea"
                    else None
                ),
                "strategy": config.mitigation.twirling_strategy,
            },
            "trex": {
                "enabled": config.mitigation.trex_enabled,
                "measure_mitigation": config.mitigation.trex_enabled,
            },
            "zne": {
                "enabled": config.mitigation.zne_enabled,
                "amplifier": config.mitigation.zne_amplifier,
                "noise_factors": config.mitigation.zne_noise_factors,
                "r2_fallback_threshold": config.mitigation.zne_r2_fallback_threshold,
            },
        },
    }

    # Conditional technique sections (only appear when relevant)
    if config.mitigation.zne_amplifier == "pea":
        snapshot["techniques"]["pea_noise_learning"] = {
            "num_randomizations": config.mitigation.num_randomizations,
            "shots_per_randomization": config.mitigation.shots_per_randomization,
            "total_learning_shots": (
                config.mitigation.num_randomizations * config.mitigation.shots_per_randomization
            ),
            "layer_pair_depths": config.mitigation.layer_pair_depths,
        }

    return snapshot


def save_run(
    result: HardwareRunResult,
    config: HardwareConfig,
    logger: StructuredLogger,
    calibration_info: dict[str, Any],
    options_dict: dict[str, Any],
    execution_mode_name: str,
    raw_per_layout: list[dict],
    zne_data: dict[str, Any],
    input_params: Any | None = None,
    transpiled_stats: dict[str, Any] | None = None,
    qpu_metrics: dict[str, Any] | None = None,
) -> Path:
    """Persist all artifacts from a single hardware execution.

    Creates ``{output_dir}/run_YYYYMMDD_HHMMSS/`` with config.json, provenance.json,
    raw_results.json, zne_analysis.json, summary.json, input_params.json,
    transpiled_circuit.json, and execution_log.json.

    Parameters
    ----------
    input_params : array-like | None
        The input parameters used for this execution. Saved for full
        reproducibility — allows re-running the exact same point.
    transpiled_stats : dict | None
        Circuit statistics post-transpilation (depth, depth_2q, gate counts,
        etc.). Saved to transpiled_circuit.json for analysis of suppression
        technique impact on circuit structure.
    qpu_metrics : dict | None
        Aggregated QPU usage metrics from _aggregate_qpu_metrics(). Contains
        total_qpu_seconds, total_billed_seconds, per_layout_qpu_s, and
        running_timestamps. Persisted in provenance.json for complete cost
        tracking. If None, falls back to inline derivation from raw_per_layout.
    """
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = Path(config.output_dir) / f"run_{ts}"
    run_dir.mkdir(parents=True, exist_ok=True)

    _write_json(asdict(config), run_dir / "config.json")
    _write_json(
        {
            "execution_timestamp": datetime.now(UTC).isoformat(),
            "backend_name": config.backend_name,
            **_collect_metadata(config.layout_seed),
            "execution_mode": execution_mode_name,
            "job_ids": result.job_ids,
            "layouts_used": result.layouts_used,
            "ces_values": result.ces_values,
            "calibration_error_rates": calibration_info,
            "options_snapshot": options_dict,
            "n_qubits": config.n_qubits,
            "layout_selection_seed": config.layout_seed,
            # QPU usage — use structured qpu_metrics if provided, else derive inline
            "total_qpu_seconds": (
                qpu_metrics.get("total_qpu_seconds")
                if qpu_metrics
                else (
                    sum(
                        r.get("qpu_seconds", 0)
                        for r in raw_per_layout
                        if isinstance(r.get("qpu_seconds"), (int, float))
                    )
                    or None
                )
            ),
            "total_billed_seconds": (
                qpu_metrics.get("total_billed_seconds") if qpu_metrics else None
            ),
            "per_layout_qpu_s": (qpu_metrics.get("per_layout_qpu_s") if qpu_metrics else None),
            "running_timestamps": (qpu_metrics.get("running_timestamps") if qpu_metrics else None),
        },
        run_dir / "provenance.json",
    )
    _write_json(
        {"n_layouts": len(raw_per_layout), "per_layout": raw_per_layout},
        run_dir / "raw_results.json",
    )
    _write_json(zne_data, run_dir / "zne_analysis.json")
    _write_json(
        {
            "h_test": result.h_value,
            "e_exact": result.e_exact,
            "e_zne": result.e_zne,
            "gap": result.gap,
            "delta_e_gap": result.delta_e_gap,
            "phase_label": result.phase_label,
            "expected_label": result.expected_label,
            "mag_x_mean": result.mag_x_mean,
            "corr_zz_mean": result.corr_zz_mean,
            "sigma": result.sigma,
            "total_shots_consumed": result.total_shots,
            "zne_r2": result.zne_r2,
            "zne_gain": result.zne_gain,
            "zne_amplifier_used": result.zne_amplifier_used,
            "mitigation_strategy": result.mitigation_strategy,
            "layout_std": result.layout_std,
            "fallback_triggered": result.fallback_triggered,
            "spsa_applied": result.spsa_applied,
            "is_partial": result.is_partial,
            "verdict": result.verdict,
            "verdict_reason": result.verdict_reason,
            # GNN-QEM post-correction
            "gnn_qem_applied": result.gnn_qem_applied,
            "gnn_qem_delta_e": result.gnn_qem_delta_e,
            "gnn_qem_confidence": result.gnn_qem_confidence,
            "e_after_gnn_qem": result.e_after_gnn_qem,
            # Affine correction
            "affine_correction_applied": result.affine_correction_applied,
            "e_after_affine": result.e_after_affine,
            # Post-QPU validation metrics (zero-cost sanity checks)
            "obs_bounds_clipped": result.obs_bounds_clipped,
            "n_obs_violations": result.n_obs_violations,
            "layout_energy_outliers": result.layout_energy_outliers,
            "e_obs_discrepancy": result.e_obs_discrepancy,
            "e_obs_cross_valid_passed": result.e_obs_cross_valid_passed,
            "n_layouts_observables": result.n_layouts_observables,
            # P2-C: Stale calibration drift (post-sweep comparison)
            "stale_calibration_t1_drift_pct": result.stale_calibration_t1_drift_pct,
            "stale_calibration_stable": result.stale_calibration_stable,
            # P3: Adaptive shot budget
            "effective_shots": result.effective_shots,
            "adaptive_shot_reason": result.adaptive_shot_reason,
            # Per-site observables (for thesis analysis)
            "per_site_x": result.per_site_x,
            "per_bond_zz": result.per_bond_zz,
            # Full mitigation configuration snapshot (auto-generated from dataclass).
            # Scalable: any new field added to MitigationOptions appears here
            # automatically. Includes execution parameters for reproducibility.
            "mitigation_config": _build_mitigation_snapshot(config),
        },
        run_dir / "summary.json",
    )

    # Save input parameters for exact reproducibility
    if input_params is not None:
        import numpy as np

        _write_json(
            {"params": np.asarray(input_params).tolist(), "n_params": len(input_params)},
            run_dir / "input_params.json",
        )

    # Save transpiled circuit statistics (depth, 2Q-depth, gate counts per layout)
    if transpiled_stats is not None:
        _write_json(transpiled_stats, run_dir / "transpiled_circuit.json")

    logger.log("run_saved", data={"run_dir": str(run_dir)})
    logger.save(run_dir / "execution_log.json")
    return run_dir


def save_partial_before_error(
    partial_results: list[dict],
    logger: StructuredLogger,
    config: HardwareConfig,
    error_msg: str,
) -> Path:
    """Save partial results before propagating an exception.

    Creates ``{output_dir}/run_YYYYMMDD_HHMMSS_PARTIAL/`` with partial_results.json,
    config.json, and execution_log.json. Never lose data on failure.
    """
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = Path(config.output_dir) / f"run_{ts}_PARTIAL"
    run_dir.mkdir(parents=True, exist_ok=True)

    _write_json(
        {"partial_results": partial_results, "error": error_msg}, run_dir / "partial_results.json"
    )
    _write_json(asdict(config), run_dir / "config.json")
    logger.log("execution_abort", data={"error": error_msg, "run_dir": str(run_dir)})
    logger.save(run_dir / "execution_log.json")
    return run_dir


def save_sweep_summary(
    results: list[HardwareRunResult],
    config: HardwareConfig,
    logger: StructuredLogger,
) -> Path:
    """Save consolidated sweep summary with per-h-point verdicts and overall pass rate.

    Writes ``{output_dir}/sweep_summary.json``. Includes full mitigation metadata,
    ZNE quality, and per-site observables for each h-point.
    """
    per_h = [
        {
            "h_value": r.h_value,
            "e_exact": r.e_exact,
            "e_zne": r.e_zne,
            "delta_e_gap": r.delta_e_gap,
            "phase_label": r.phase_label,
            "expected_label": r.expected_label,
            "verdict": r.verdict,
            "verdict_reason": r.verdict_reason,
            "zne_r2": r.zne_r2,
            "zne_amplifier_used": r.zne_amplifier_used,
            "mitigation_strategy": r.mitigation_strategy,
            "layout_std": r.layout_std,
            "fallback_triggered": r.fallback_triggered,
            "spsa_applied": r.spsa_applied,
            "is_partial": r.is_partial,
            "total_shots": r.total_shots,
            "mag_x_mean": r.mag_x_mean,
            "corr_zz_mean": r.corr_zz_mean,
            # Post-correction
            "gnn_qem_applied": r.gnn_qem_applied,
            "affine_correction_applied": r.affine_correction_applied,
            "e_after_affine": r.e_after_affine,
            # Post-QPU validation
            "obs_bounds_clipped": r.obs_bounds_clipped,
            "layout_energy_outliers": r.layout_energy_outliers,
            "e_obs_discrepancy": r.e_obs_discrepancy,
            "e_obs_cross_valid_passed": r.e_obs_cross_valid_passed,
            "n_layouts_observables": r.n_layouts_observables,
        }
        for r in results
    ]
    n_pass = sum(1 for r in results if r.verdict == "PASS")
    n_indeterminate = sum(1 for r in results if r.verdict == "INDETERMINATE")

    import numpy as np

    de_gaps = [r.delta_e_gap for r in results]
    summary = {
        "n_points": len(results),
        "n_pass": n_pass,
        "n_indeterminate": n_indeterminate,
        "pass_rate": n_pass / len(results) if results else 0.0,
        "mean_delta_e_gap": float(np.mean(de_gaps)) if de_gaps else None,
        "std_delta_e_gap": float(np.std(de_gaps, ddof=1)) if len(de_gaps) > 1 else None,
        "max_delta_e_gap": float(np.max(de_gaps)) if de_gaps else None,
        "amplifier_used": results[0].zne_amplifier_used if results else None,
        "total_shots_all": sum(r.total_shots for r in results),
        "per_h_point": per_h,
    }
    out_path = Path(config.output_dir) / "sweep_summary.json"
    _write_json(summary, out_path)
    logger.log(
        "sweep_summary_saved", data={"path": str(out_path), "pass_rate": summary["pass_rate"]}
    )
    return out_path
