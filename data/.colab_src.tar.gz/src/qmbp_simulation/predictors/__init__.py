"""Predictors submodule — MPNN parameter prediction + GNN-QEM error correction."""

from qmbp_simulation.predictors.gnn_qem import (
    GNNQEMConfig,
    GNNQEMCorrector,
    QEMCorrectionResult,
    QEMSample,
    QEMTrainResult,
    build_qem_dataset,
    build_qem_graph,
    correct_energy,
    generate_qem_training_data,
    load_qem_checkpoint,
    load_qem_samples,
    save_qem_checkpoint,
    save_qem_samples,
    train_gnn_qem,
)
from qmbp_simulation.predictors.model_zoo import (
    ZooEntry,
    list_pretrained,
    load_pretrained,
    register_checkpoint,
)
from qmbp_simulation.predictors.mpnn import (
    BondResolvedMPNN,
    MPNNPredictor,
    build_bond_resolved_graph,
    build_graph_dataset,
    load_mpnn_checkpoint,
    predict_theta,
    save_mpnn_checkpoint,
    train_bond_resolved_mpnn,
    train_mpnn,
)
from qmbp_simulation.predictors.unified_graph import (
    NODE_TYPE_QUBIT,
    NODE_TYPE_RX_GATE,
    NODE_TYPE_ZZ_GATE,
    UNIFIED_NODE_FEATURES,
    build_unified_bond_resolved_graph,
    build_unified_dataset,
    compute_graph_metrics,
    validate_unified_graph,
)
from qmbp_simulation.predictors.unified_mpnn import (
    UnifiedMPNN,
    load_unified_checkpoint,
    save_unified_checkpoint,
    train_unified_mpnn,
)

__all__ = [
    # Phase 3: MPNN parameter predictor
    "MPNNPredictor",
    "build_graph_dataset",
    "load_mpnn_checkpoint",
    "save_mpnn_checkpoint",
    "train_mpnn",
    # Phase 3b: Bond-resolved cross-N predictor
    "BondResolvedMPNN",
    "build_bond_resolved_graph",
    "train_bond_resolved_mpnn",
    # Phase 3c: Unified Hamiltonian+Circuit graph (Qracle-style)
    "build_unified_bond_resolved_graph",
    "build_unified_dataset",
    "validate_unified_graph",
    "compute_graph_metrics",
    "NODE_TYPE_QUBIT",
    "NODE_TYPE_ZZ_GATE",
    "NODE_TYPE_RX_GATE",
    "UNIFIED_NODE_FEATURES",
    # Phase 3d: Type-aware UnifiedMPNN (Qracle-inspired architecture)
    "UnifiedMPNN",
    "train_unified_mpnn",
    "save_unified_checkpoint",
    "load_unified_checkpoint",
    # Phase 4+: GNN-QEM error correction
    "GNNQEMCorrector",
    "GNNQEMConfig",
    "QEMSample",
    "QEMTrainResult",
    "QEMCorrectionResult",
    "build_qem_graph",
    "build_qem_dataset",
    "train_gnn_qem",
    "correct_energy",
    "generate_qem_training_data",
    "save_qem_checkpoint",
    "load_qem_checkpoint",
    "save_qem_samples",
    "load_qem_samples",
    # External benchmarks subpackage
    "external_benchmarks",
    # Model zoo (pre-trained MPNN registry)
    "load_pretrained",
    "list_pretrained",
    "register_checkpoint",
    "ZooEntry",
]
