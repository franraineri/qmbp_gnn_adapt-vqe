"""Unified MPNN — Type-aware GNN for Qracle-style Hamiltonian+Circuit graphs.

Extends BondResolvedMPNN with type-aware message passing: different node types
(qubit, ZZ gate, RX gate) use distinct message functions, enabling the GNN to
exploit the heterogeneous structure of the unified graph.

Key differences from BondResolvedMPNN:
  1. Type-conditioned message passing via per-type GINConv layers
  2. Gate-node readout: θ_zz predicted directly from ZZ gate embeddings
  3. Qubit-node readout: θ_x predicted directly from qubit node embeddings
  4. No concatenation trick for edge prediction — gate nodes carry the info

Architecture (Qracle-inspired, adapted for bond-resolved HVA):
  Input: Unified graph from build_unified_bond_resolved_graph()
  Type-Conditioned MP: k layers of {GINConv_qubit, GINConv_gate} with shared state
  Readout:
    - θ_x: qubit_embedding → node_head → [N values]
    - θ_zz: zz_gate_embedding → gate_head → [n_edges values]

References
----------
- Zhang et al. (2025) "Qracle" arXiv:2505.01236
- Integration plan: internal/documentation/next-steps/04_qracle_unified_graph.md
"""

from __future__ import annotations

import logging

import numpy as np
import torch
import torch.nn as nn
from torch_geometric.data import Data
from torch_geometric.nn import GINConv

from qmbp_simulation.predictors.unified_graph import (
    NODE_TYPE_QUBIT,
    NODE_TYPE_RX_GATE,
    NODE_TYPE_ZZ_GATE,
    UNIFIED_NODE_FEATURES,
)

logger = logging.getLogger(__name__)


class UnifiedMPNN(nn.Module):
    """Type-aware MPNN for Qracle-style unified Hamiltonian+Circuit graphs.

    This model processes the heterogeneous unified graph with type-conditioned
    message passing. Unlike BondResolvedMPNN which applies uniform GINConv
    to all nodes, UnifiedMPNN routes messages through type-specific pathways:

    - **Shared backbone**: All nodes participate in the same GINConv layers
      (messages flow freely between qubit, ZZ gate, and RX gate nodes)
    - **Type embedding**: A learned type embedding is added to node features
      at input, giving the GNN explicit node-type awareness
    - **Type-aware readout**: Predictions extracted from specific node types:
      - θ_zz[i]: from ZZ gate node i (one per lattice edge per layer)
      - θ_x[j]: from qubit node j (one per qubit per layer)

    This is more principled than BondResolvedMPNN's approach of masking at
    readout, because here the ZZ gate nodes LEARN to represent θ_zz during
    message passing (they aggregate information from their connected qubits).

    Parameters
    ----------
    node_features : int
        Input node features from unified graph (default 4: UNIFIED_NODE_FEATURES).
    hidden_dim : int
        Hidden dimension for GNN layers.
    n_layers : int
        Number of GINConv message passing layers.
    norm_type : str
        Normalization: 'none' (default, best cross-N), 'batch', or 'layer'.
    dropout : float
        Dropout rate in prediction heads.
    type_embedding_dim : int
        Learned type embedding dimension (added to hidden representation).
        Set to 0 to disable type embeddings (pure positional encoding via
        the node_type feature in x[:, 3]).
    gate_readout : bool
        If True (default), predict θ_zz from ZZ gate node embeddings.
        If False, use edge concatenation (BondResolvedMPNN-style fallback).
    """

    def __init__(
        self,
        node_features: int = UNIFIED_NODE_FEATURES,
        hidden_dim: int = 256,
        n_layers: int = 3,
        norm_type: str = "none",
        dropout: float = 0.1,
        type_embedding_dim: int = 16,
        gate_readout: bool = True,
    ) -> None:
        super().__init__()

        if norm_type not in ("batch", "layer", "none"):
            raise ValueError(f"norm_type must be 'batch', 'layer', or 'none'. Got: {norm_type!r}")

        self.node_features = node_features
        self.hidden_dim = hidden_dim
        self.n_layers = n_layers
        self.norm_type = norm_type
        self.dropout_rate = dropout
        self.type_embedding_dim = type_embedding_dim
        self.gate_readout = gate_readout

        # ── Type embedding (learned) ─────────────────────────────────
        n_types = 3  # qubit=0, zz_gate=1, rx_gate=2
        if type_embedding_dim > 0:
            self.type_emb = nn.Embedding(n_types, type_embedding_dim)
            effective_input_dim = node_features + type_embedding_dim
        else:
            self.type_emb = None
            effective_input_dim = node_features

        # ── Message passing backbone ─────────────────────────────────
        self.convs = nn.ModuleList()
        self.norms = nn.ModuleList()

        def _make_norm(dim: int) -> nn.Module:
            if norm_type == "batch":
                return nn.BatchNorm1d(dim)
            elif norm_type == "layer":
                return nn.LayerNorm(dim)
            return nn.Identity()

        # First layer: effective_input_dim → hidden_dim
        mlp0 = nn.Sequential(
            nn.Linear(effective_input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.convs.append(GINConv(mlp0))
        self.norms.append(_make_norm(hidden_dim))

        # Subsequent layers: hidden_dim → hidden_dim
        for _ in range(n_layers - 1):
            mlp = nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim),
            )
            self.convs.append(GINConv(mlp))
            self.norms.append(_make_norm(hidden_dim))

        # ── Readout heads ────────────────────────────────────────────
        # θ_x: per-qubit prediction from qubit node embeddings
        self.qubit_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, 1),
        )

        if gate_readout:
            # θ_zz: per-gate prediction from ZZ gate node embeddings
            # Each ZZ gate node represents one bond — predict its θ_zz directly
            self.gate_head = nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim // 2),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim // 2, 1),
            )
            self.edge_head = None
        else:
            # Fallback: edge concatenation (same as BondResolvedMPNN)
            self.gate_head = None
            self.edge_head = nn.Sequential(
                nn.Linear(2 * hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, 1),
            )

    def forward(self, data: Data) -> torch.Tensor:
        """Predict bond-resolved θ = [θ_zz_edges, θ_x_nodes] × p_layers.

        Parameters
        ----------
        data : Data
            Unified graph from build_unified_bond_resolved_graph() with:
            - x: [total_nodes, UNIFIED_NODE_FEATURES]
            - edge_index: [2, total_edges]
            - node_type: [total_nodes] with values 0/1/2
            - edge_list: [n_edges, 2] unique lattice edges (qubit indices)
            - n_qubit_nodes: int
            - n_edges_unique: int

        Returns
        -------
        torch.Tensor of shape [1, (n_edges + n_qubit_nodes) * p_layers]
            For p=1: [1, n_edges + N]
            For p>1: [1, (n_edges + N) * p] with layout matching theta_opt

        Raises
        ------
        RuntimeError
            If data is missing required attributes (node_type, edge_list, etc.)
        """
        x = data.x
        edge_index = data.edge_index

        # Input validation
        if not hasattr(data, "node_type") or data.node_type is None:
            raise RuntimeError(
                "UnifiedMPNN requires unified graphs with node_type attribute. "
                "Use build_unified_bond_resolved_graph(include_circuit_nodes=True)."
            )
        node_type = data.node_type

        # ── Prepend type embedding if enabled ────────────────────────
        if self.type_emb is not None:
            type_emb = self.type_emb(node_type)  # [total_nodes, type_emb_dim]
            x = torch.cat([x, type_emb], dim=-1)  # [total_nodes, feat + emb]

        # ── Message passing (all nodes participate) ──────────────────
        for conv, norm in zip(self.convs, self.norms, strict=False):
            x = conv(x, edge_index)
            x = norm(x)
            x = torch.relu(x)

        # ── Extract embeddings by node type ──────────────────────────
        qubit_mask = node_type == NODE_TYPE_QUBIT
        zz_gate_mask = node_type == NODE_TYPE_ZZ_GATE
        rx_gate_mask = node_type == NODE_TYPE_RX_GATE

        x_qubit = x[qubit_mask]  # [N, hidden_dim]
        x_zz_gates = x[zz_gate_mask]  # [n_edges * p_layers, hidden_dim]
        x_rx_gates = x[rx_gate_mask]  # [N * p_layers, hidden_dim]

        n_edges = data.n_edges_unique
        N = data.n_qubit_nodes

        # Infer p_layers from gate node counts
        n_zz_total = x_zz_gates.shape[0]
        p_layers = n_zz_total // n_edges if n_edges > 0 else 1

        # ── θ_zz: predict from ZZ gate embeddings ────────────────────
        if self.gate_readout:
            # Direct gate readout: each ZZ gate node → one θ_zz value.
            theta_zz = self.gate_head(x_zz_gates).squeeze(-1)  # [n_edges * p]
        else:
            # Fallback: concatenate qubit embeddings at edge endpoints
            # For p>1, repeat edge_list predictions per layer
            edge_list = data.edge_list  # [n_edges, 2]
            src_emb = x_qubit[edge_list[:, 0]]
            tgt_emb = x_qubit[edge_list[:, 1]]
            edge_emb = torch.cat([src_emb, tgt_emb], dim=-1)
            theta_zz_layer = self.edge_head(edge_emb).squeeze(-1)  # [n_edges]
            # For p>1 with edge fallback, repeat (qubit embeddings don't change per layer)
            theta_zz = theta_zz_layer.repeat(p_layers)

        # ── θ_x: predict from RX gate embeddings (p>1) or qubits (p=1) ─
        if p_layers > 1 and x_rx_gates.shape[0] > 0:
            # For p>1: use RX gate node embeddings (one per qubit per layer)
            theta_x = self.qubit_head(x_rx_gates).squeeze(-1)  # [N * p]
        else:
            # For p=1: use qubit node embeddings directly
            theta_x = self.qubit_head(x_qubit).squeeze(-1)  # [N]

        # ── Concatenate: [θ_zz_layer1, θ_x_layer1, θ_zz_layer2, ...] ─
        # Target layout from build_unified_bond_resolved_graph:
        #   [θ_zz_all_layers, θ_x_all_layers] (not interleaved)
        # = [zz_l1(n_e), zz_l2(n_e), ..., x_l1(N), x_l2(N), ...]
        # Actually the layout is: (n_edges + N) * p_layers as flat vector
        # with first n_edges*p = ZZ params, then N*p = X params
        return torch.cat([theta_zz, theta_x], dim=-1).unsqueeze(0)


def train_unified_mpnn(
    model: UnifiedMPNN,
    dataset: list[Data],
    n_epochs: int = 6000,
    lr: float = 1e-3,
    patience: int = 300,
    seed: int = 42,
    weight_decay: float = 1e-4,
    val_fraction: float = 0.2,
) -> dict:
    """Train the UnifiedMPNN with per-edge/per-node MSE loss.

    Uses the same training pattern as train_bond_resolved_mpnn but with
    weight decay by default (unified graphs are larger → higher overfitting
    risk) and train/val split for generalization monitoring.

    Parameters
    ----------
    model : UnifiedMPNN
        Model to train.
    dataset : list[Data]
        Training graphs from build_unified_bond_resolved_graph() with y targets.
    n_epochs : int
        Maximum training epochs.
    lr : float
        Initial learning rate.
    patience : int
        ReduceLROnPlateau patience.
    seed : int
        Random seed.
    weight_decay : float
        L2 regularization (default 1e-4, higher than BondResolvedMPNN).
    val_fraction : float
        Fraction held out for validation (0.0 disables).

    Returns
    -------
    dict with training metrics matching train_bond_resolved_variant output format.
    """
    import torch.nn.functional as F

    if len(dataset) < 3:
        raise ValueError(f"Need ≥3 training points, got {len(dataset)}.")

    torch.manual_seed(seed)

    # Train/val split
    rng = np.random.default_rng(seed)
    n_total = len(dataset)
    n_val = int(n_total * val_fraction) if val_fraction > 0 else 0
    if n_val > 0 and n_total - n_val < 3:
        n_val = 0

    if n_val > 0:
        indices = rng.permutation(n_total)
        val_indices = set(indices[:n_val].tolist())
        train_dataset = [dataset[i] for i in range(n_total) if i not in val_indices]
        val_dataset = [dataset[i] for i in val_indices]
    else:
        train_dataset = dataset
        val_dataset = []

    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, patience=patience, factor=0.5, min_lr=1e-6
    )

    mse_history: list[float] = []
    val_mse_history: list[float] = []
    zz_loss_history: list[float] = []
    x_loss_history: list[float] = []

    model.train()
    for epoch in range(n_epochs):
        total_loss = 0.0
        total_zz = 0.0
        total_x = 0.0

        for data in train_dataset:
            optimizer.zero_grad()
            pred = model(data).squeeze(0)
            target = data.y
            n_e = data.n_edges_unique

            # Infer p_layers from target size vs n_edges + N
            N = data.n_qubit_nodes
            p_inferred = len(target) // (n_e + N) if (n_e + N) > 0 else 1

            # Prediction layout: [θ_zz_all_layers, θ_x_all_layers]
            # Target layout: [θ_zz_l1, θ_x_l1, θ_zz_l2, θ_x_l2, ...]
            # Need to rearrange target to match prediction layout
            if p_inferred > 1:
                # Reshape target from interleaved to grouped
                target_layers = target.reshape(p_inferred, n_e + N)
                target_zz = target_layers[:, :n_e].reshape(-1)  # all ZZ
                target_x = target_layers[:, n_e:].reshape(-1)   # all X
                target_grouped = torch.cat([target_zz, target_x])
            else:
                target_grouped = target

            n_zz_total = n_e * p_inferred
            loss_zz = F.mse_loss(pred[:n_zz_total], target_grouped[:n_zz_total])
            loss_x = F.mse_loss(pred[n_zz_total:], target_grouped[n_zz_total:])
            loss = loss_zz + loss_x

            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            total_loss += loss.item()
            total_zz += loss_zz.item()
            total_x += loss_x.item()

        avg_loss = total_loss / len(train_dataset)
        mse_history.append(avg_loss)
        zz_loss_history.append(total_zz / len(train_dataset))
        x_loss_history.append(total_x / len(train_dataset))
        scheduler.step(avg_loss)

        # Validation every 50 epochs
        if val_dataset and epoch % 50 == 0:
            model.eval()
            val_loss = 0.0
            with torch.no_grad():
                for data in val_dataset:
                    pred = model(data).squeeze(0)
                    target = data.y
                    n_e = data.n_edges_unique
                    N_v = data.n_qubit_nodes
                    p_v = len(target) // (n_e + N_v) if (n_e + N_v) > 0 else 1
                    if p_v > 1:
                        tl = target.reshape(p_v, n_e + N_v)
                        tg = torch.cat([tl[:, :n_e].reshape(-1), tl[:, n_e:].reshape(-1)])
                    else:
                        tg = target
                    n_zz_v = n_e * p_v
                    loss_v = F.mse_loss(pred[:n_zz_v], tg[:n_zz_v]) + \
                             F.mse_loss(pred[n_zz_v:], tg[n_zz_v:])
                    val_loss += loss_v.item()
            val_mse_history.append(val_loss / len(val_dataset))
            model.train()

        if (epoch + 1) % 1000 == 0:
            logger.info(
                "  Epoch %d: MSE=%.2e (ZZ=%.2e, X=%.2e)",
                epoch + 1, avg_loss,
                total_zz / len(train_dataset),
                total_x / len(train_dataset),
            )

        # Early stopping on LR exhaustion
        if optimizer.param_groups[0]["lr"] <= 1e-6 and epoch > 500:
            break

    # Final val MSE
    final_val_mse = None
    if val_dataset:
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for data in val_dataset:
                pred = model(data).squeeze(0)
                target = data.y
                n_e = data.n_edges_unique
                N_v = data.n_qubit_nodes
                p_v = len(target) // (n_e + N_v) if (n_e + N_v) > 0 else 1
                if p_v > 1:
                    tl = target.reshape(p_v, n_e + N_v)
                    tg = torch.cat([tl[:, :n_e].reshape(-1), tl[:, n_e:].reshape(-1)])
                else:
                    tg = target
                n_zz_v = n_e * p_v
                loss_v = F.mse_loss(pred[:n_zz_v], tg[:n_zz_v]) + \
                         F.mse_loss(pred[n_zz_v:], tg[n_zz_v:])
                val_loss += loss_v.item()
        final_val_mse = val_loss / len(val_dataset)

    final_mse = mse_history[-1] if mse_history else float("inf")
    gen_gap = (final_val_mse - final_mse) if final_val_mse is not None else None

    return {
        "final_mse": float(final_mse),
        "final_zz_mse": float(zz_loss_history[-1]) if zz_loss_history else float("inf"),
        "final_x_mse": float(x_loss_history[-1]) if x_loss_history else float("inf"),
        "val_mse": float(final_val_mse) if final_val_mse is not None else None,
        "generalization_gap": float(gen_gap) if gen_gap is not None else None,
        "mse_history": mse_history,
        "zz_loss_history": zz_loss_history,
        "x_loss_history": x_loss_history,
        "val_mse_history": val_mse_history,
        "n_epochs_run": len(mse_history),
        "n_train": len(train_dataset),
        "n_val": len(val_dataset),
        "stopped_early": len(mse_history) < n_epochs,
        "stop_reason": "lr_exhausted" if len(mse_history) < n_epochs else "completed",
    }


# ── Checkpoint save/load (same pattern as mpnn.py) ───────────────────────


def save_unified_checkpoint(
    model: UnifiedMPNN,
    path: str,
    training_metadata: dict | None = None,
) -> None:
    """Save UnifiedMPNN with architecture metadata for reconstruction.

    Uses the same envelope format as save_mpnn_checkpoint for consistency.
    Checkpoints are interoperable with the artifact_store system.

    Parameters
    ----------
    model : UnifiedMPNN
        Trained model to save.
    path : str
        File path for the checkpoint (.pt file).
    training_metadata : dict | None
        Optional training info (epochs, loss, dataset details).
    """
    torch.save(
        {
            "state_dict": model.state_dict(),
            "architecture": "unified_mpnn",
            "node_features": model.node_features,
            "hidden_dim": model.hidden_dim,
            "n_layers": model.n_layers,
            "norm_type": model.norm_type,
            "dropout": model.dropout_rate,
            "type_embedding_dim": model.type_embedding_dim,
            "gate_readout": model.gate_readout,
            "training_metadata": training_metadata or {},
        },
        path,
    )
    logger.info("Saved UnifiedMPNN checkpoint to %s", path)


def load_unified_checkpoint(path: str, eval_mode: bool = True) -> UnifiedMPNN:
    """Load UnifiedMPNN from checkpoint, reconstructing architecture.

    Parameters
    ----------
    path : str
        Path to the checkpoint file (.pt).
    eval_mode : bool
        If True (default), set model to eval mode after loading.
        Set to False for fine-tuning (caller will call model.train()).

    Returns
    -------
    UnifiedMPNN
        Reconstructed model with loaded weights.
    """
    data = torch.load(path, map_location="cpu", weights_only=False)

    model = UnifiedMPNN(
        node_features=data.get("node_features", UNIFIED_NODE_FEATURES),
        hidden_dim=data.get("hidden_dim", 256),
        n_layers=data.get("n_layers", 3),
        norm_type=data.get("norm_type", "none"),
        dropout=data.get("dropout", 0.1),
        type_embedding_dim=data.get("type_embedding_dim", 16),
        gate_readout=data.get("gate_readout", True),
    )
    model.load_state_dict(data["state_dict"])

    if eval_mode:
        model.eval()

    logger.info(
        "Loaded UnifiedMPNN: hidden=%d, layers=%d, type_emb=%d, gate_readout=%s",
        model.hidden_dim, model.n_layers,
        model.type_embedding_dim, model.gate_readout,
    )
    return model
